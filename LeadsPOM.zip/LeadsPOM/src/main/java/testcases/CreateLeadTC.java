package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import baseclass.LeadsSpecificMethods;
import pages.LoginPage;

public class CreateLeadTC extends LeadsSpecificMethods{
	
	@BeforeTest
	public void setFileName() {
		// TODO Auto-generated method stub
		excelFile="LeadsPOMdata";
	}

	@Test(dataProvider="sendData")
	public void runTestCreateLead(String username, String password,String companyName,String firstName,String lastName,String phoneNum,String newCompanyName,String firstNameMergeLeadsFrom,String firstNameMergeLeadsTo,String leadID) {
		// TODO Auto-generated method stub
		new LoginPage(driver)
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin()
		.clickCRMSFA()
		.clickLeads()
		.createLead()
		.enterCompanyName(companyName)
		.enterFirstName(firstName)
		.enterLastName(lastName)
		.enterPhoneNum(phoneNum)
		.clickCreateButton();
	}
}
