package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import baseclass.LeadsSpecificMethods;
import pages.LoginPage;

public class DuplicateLeadTC extends LeadsSpecificMethods{
	
	@BeforeTest
	public void setFileName() {
		// TODO Auto-generated method stub
		excelFile="LeadsPOMdata";
	}

	@Test(dataProvider="sendData")
	public void runTestDuplicateLead(String username, String password,String companyName,String firstName,String lastName,String phoneNum,String newCompanyName,String firstNameMergeLeadsFrom,String firstNameMergeLeadsTo,String leadID) throws InterruptedException {
		// TODO Auto-generated method stub
		new LoginPage(driver)
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin()
		.clickCRMSFA()
		.clickLeads()
		.findLead()
		.clickPhone()
		.enterPhoneNum(phoneNum)
		.clickFindLeads()
		.clickLeadID()
		.clickDuplicateLead()
		.clickCreateButton();
	}


}
