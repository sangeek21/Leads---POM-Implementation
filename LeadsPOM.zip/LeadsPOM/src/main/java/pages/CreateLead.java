package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import baseclass.LeadsSpecificMethods;

public class CreateLead extends LeadsSpecificMethods{
	public CreateLead(ChromeDriver driver) {
	this.driver=driver;
	}
	
	public CreateLead enterCompanyName(String companyName) {
		// TODO Auto-generated method stub
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(companyName);
		return this;
	}
	
	public CreateLead updateCompanyName(String newCompanyName) {
		// TODO Auto-generated method stub
		driver.findElement(By.id("updateLeadForm_companyName")).sendKeys(newCompanyName);
		return this;
	}
	

	public CreateLead enterFirstName(String firstName) {
		// TODO Auto-generated method stub
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(firstName);
		return this;
	}
	
	public CreateLead enterLastName(String lastName) {
		// TODO Auto-generated method stub
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys("R");
		return this;
	}
	
	public CreateLead enterPhoneNum(String phoneNum) {
		// TODO Auto-generated method stub
		driver.findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys(phoneNum);
		return this;
	}
	
	public ViewLead clickCreateButton() {
		// TODO Auto-generated method stub
		driver.findElement(By.name("submitButton")).click();
		return new ViewLead(driver);
	}
}
