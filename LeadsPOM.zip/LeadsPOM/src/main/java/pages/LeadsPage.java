package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import baseclass.LeadsSpecificMethods;

public class LeadsPage extends LeadsSpecificMethods{
	public LeadsPage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public CreateLead createLead() {
		// TODO Auto-generated method stub
		driver.findElement(By.linkText("Create Lead")).click();
		return new CreateLead(driver);
	}
	
	public FindLeads findLead() {
		// TODO Auto-generated method stub
		driver.findElement(By.linkText("Find Leads")).click();
		return new FindLeads(driver);
	}
	
	public MergeLeads mergeLead() {
		// TODO Auto-generated method stub
		driver.findElement(By.linkText("Merge Leads")).click();
		return new MergeLeads(driver);
	}
}
