package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import baseclass.LeadsSpecificMethods;

public class ViewLead extends LeadsSpecificMethods{
	public ViewLead(ChromeDriver driver,String leadID) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}
	
	public ViewLead(ChromeDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}
	
	public CreateLead clickDuplicateLead() {
		// TODO Auto-generated method stub
		return new CreateLead(driver);
	}
	
	public EditLead clickEdit() {
		// TODO Auto-generated method stub
		driver.findElement(By.linkText("Edit")).click();
		return new EditLead(driver);
	}	
	
	public LeadsPage clickDelete() {
		// TODO Auto-generated method stub
		driver.findElement(By.linkText("Delete")).click();
		return new LeadsPage(driver);
	}
	
	

}
