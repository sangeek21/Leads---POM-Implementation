package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import baseclass.LeadsSpecificMethods;

public class MyHome extends LeadsSpecificMethods {
	public MyHome(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public LeadsPage clickLeads() {
		// TODO Auto-generated method stub
		driver.findElement(By.linkText("Leads")).click();
		return new LeadsPage(driver);
	}
}
