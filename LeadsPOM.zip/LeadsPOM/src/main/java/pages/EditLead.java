package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import baseclass.LeadsSpecificMethods;

public class EditLead extends LeadsSpecificMethods{
	public EditLead(ChromeDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}
	
	public EditLead updateCompanyName(String newCompanyName) {
		// TODO Auto-generated method stub
		driver.findElement(By.id("updateLeadForm_companyName")).clear();
		driver.findElement(By.id("updateLeadForm_companyName")).sendKeys(newCompanyName);
		return this;
	}
	public ViewLead clickSubmit() {
		// TODO Auto-generated method stub
		driver.findElement(By.name("submitButton")).click();
		return new ViewLead(driver);
	}

}
