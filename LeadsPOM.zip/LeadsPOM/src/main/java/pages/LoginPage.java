package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import baseclass.LeadsSpecificMethods;

public class LoginPage extends LeadsSpecificMethods{
	
	public LoginPage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public LoginPage enterUserName(String username) {
		// TODO Auto-generated method stub
		driver.findElement(By.id("username")).sendKeys(username);
		return this;
	}
	
	public LoginPage enterPassword(String password) {
		// TODO Auto-generated method stub
		driver.findElement(By.id("password")).sendKeys(password);
		return this;
	}

	public WelcomePage clickLogin() {
		// TODO Auto-generated method stub
		driver.findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage(driver);
	}


}
