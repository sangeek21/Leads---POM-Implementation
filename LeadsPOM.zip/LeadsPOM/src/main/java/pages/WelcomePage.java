package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import baseclass.LeadsSpecificMethods;

public class WelcomePage extends LeadsSpecificMethods {
public WelcomePage(ChromeDriver driver) {
	// TODO Auto-generated constructor stub
	this.driver=driver;
}

public MyHome clickCRMSFA() {
	// TODO Auto-generated method stub
	driver.findElement(By.linkText("CRM/SFA")).click();
	return new MyHome(driver);
}
}
