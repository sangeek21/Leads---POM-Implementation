package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import baseclass.LeadsSpecificMethods;

public class FindLeads extends LeadsSpecificMethods{
	public FindLeads(ChromeDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}
	
	public FindLeads clickPhone() {
		// TODO Auto-generated method stub
		driver.findElement(By.xpath("//span[text()='Phone']")).click();
		return this;
	}
	
	public FindLeads enterPhoneNum(String phoneNum) {
		// TODO Auto-generated method stub
		driver.findElement(By.xpath("//input[@name='phoneNumber']")).sendKeys(phoneNum);
		return this;
	}
	public FindLeads clickFindLeads() throws InterruptedException {
		// TODO Auto-generated method stub
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(2000);
		return this;
	}
	public ViewLead clickLeadID() throws InterruptedException {
		// TODO Auto-generated method stub
		Thread.sleep(2000);
		String leadID;
		leadID = driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).getText();
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
		System.out.println("Lead Searched: "+leadID);
		return new ViewLead(driver,leadID);
	}
	
	public FindLeads enterLeadID(String leadID) {
		// TODO Auto-generated method stub
		driver.findElement(By.xpath("//input[@name='id']")).sendKeys(leadID);
		return this;
	}
	
	public ViewLead verifyLeadDelete() throws InterruptedException {
		// TODO Auto-generated method stub
		Thread.sleep(2000);
		if(driver.findElement(By.className("x-paging-info")).isDisplayed()) {			
			String text = driver.findElement(By.className("x-paging-info")).getText();
			if (text.equals("No records to display")) {
				System.out.println("Text matched");
			} else {
				System.out.println("Text not matched");
			}
		}
		else
			System.out.println("Not Found");
		return new ViewLead(driver);
	}
	

}
