package utils;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {

	public static String[][] readData(String fileName) throws IOException{
		XSSFWorkbook wb = new XSSFWorkbook("./src/main/resources/data/"+fileName+".xlsx");
		XSSFSheet sheet = wb.getSheet("Sheet1");
		int lastRowNum = sheet.getLastRowNum();
		int lastCellNum = sheet.getRow(0).getLastCellNum();
		String[][] data=new String[lastRowNum][lastCellNum];
		for(int i=1;i<=lastRowNum;i++) {
			for(int j=0;j<lastCellNum;j++) {
				data[i-1][j]=sheet.getRow(i).getCell(j).getStringCellValue();
				//System.out.println(sheet.getRow(i).getCell(j).getStringCellValue());
			}
		}
		wb.close();
		return data;
	}

}
